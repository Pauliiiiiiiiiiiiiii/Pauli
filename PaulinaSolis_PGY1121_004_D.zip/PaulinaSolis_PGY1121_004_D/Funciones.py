import os
import numpy as np 
import Validaciones as va
from Funciones import llenar,validaOp,comprarDepartamento,validatipo,mostrarDisponibles,totalGanancias,Listado
mtz=np.empty([10,4],type(int))
mtz=np.empty([10,4],type(int))
rut=[]
va.llenar(,mtz,tipo)
op=0
dep=0
sumar=0
tipo=0
piso=0
while(op!=5):
    os.system("cls")
    print("1. Comprar departamento") 
    print("2. Mostrar departamentos disponibles") 
    print("3. Ver listado de compradores") 
    print("4. Mostrar ganancias totales")
    print("5. Salir")
    op=va.validaOp()
    if(op==1):
        va.mostrarDisponibles(mtz,dep,tipo)
        tipo=va.validatipo()
        cc=va.disponible(tipo)
        if (cc): 
            print("Este departamento está disponible!")
        else:
            print("No está dsponible")
            pago=va.comprarDepartamento(mtz,dep,tipo,piso,rut )
            print("\t Su total de compra es: $", pago)
            os.system("pause")
    if(op==2):
        va.mostrarDisponibles(mtz)
        os.system("pause")
    if(op==3):
            va.Listado(rut)
            os.system("pause")
    if(op==4):
        suma=0
        suma=va.totalGanancias(tipo)
        if(suma==0):
            print("\t Aún no se han vendido departamentos")
        else:
            print("\t El total de las ganancias es de : $", sumar)
        os.system("pause")
    if(op==5):
        print("Hasta Pronto!!")



