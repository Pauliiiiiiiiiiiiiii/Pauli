import os
import numpy as np
import random
def llenar(departamento,tipo,mtz): 
    p=1
    for i in range(10):
        for j in range(4):
            departamento[i,j]=p 
            tipo[i,j]=p 
            p+=1 
def validaOp():
    pp=0
    while(True):
        try:
            pp=int(input("  Elija una opción: "))
            if(pp>=1 and pp<=5):
                break
            else:
                print("Debe ingresar una opción entre 1 y 5!")
        except ValueError:
            print("Debe ser un número entero entre 1 y 5!")
    return pp

def comprarDepartamento(departamento,tipo,rut,mtz):
    if(tipo=="Tipo A"):
        pago=3.800
    if(tipo=="Tipo B"):
        pago=3.000
    if(tipo=="Tipo C"):
        pago=2.800
    if(tipo=="Tipo D"):
        pago=3.500
    for i in range(11):
        for j in range(5):
            if(tipo==departamento[i,j]):
                while(True):
                    while(True):
                        try:
                            rut=int(input("Escriba los primeros 8 digitos de su rut.(Sin puntos ni digito verificador) "))
                            if(rut<9999999):
                                print("Deben ser 8 dígitos maximo!")
                            else:
                                break
                        except ValueError:
                            print("Debe ser número entero!")
                    if(len(rut)>0): 
                        sw=0
                        for y in range(len(rut)):
                            if(rut==rut[y]):
                                sw=1
                        if(sw==1):
                            print("Rut ya ingresado! Intente con otro.")
                        else:
                            rut.append(rut)
                            break
                    else:
                        rut.append(rut)
                        break
def validatipo():
    tipo=0
    while(True):
        try:
            tipo=int(input(" Ingrese número de tipo entre 1-4: "))
            if(tipo>=1 and tipo<=4):
                break
            else:
                print("Debe elegir entre alguno de los tipos de departamento entre 1 y 4.")
        except ValueError:
            print("Debe ser un número entero")
    return tipo 
def mostrarDisponibles(mtz):
    print("| PISO  |      TIPO     |")
    print("|       | A | B | C | D |")
    for i in range(10):
        print("|  ",mtz(i+1),"  |",mtz[i][0],"|",mtz[i][1],"|",mtz[i][2],"|",mtz[i][3],"|")

def totalGanancias(departamento):
    suma=0
    for i in range(10):
        for j in range(4):
            if(departamento[i,j]!=0 and departamento[i,j]>4):
                suma+=departamento[i,j]
    return suma
def Listado(r):
    r.sort()
    print(" Listado de compradores. Orden: Menor a Mayor ")
    print("\t",r)
